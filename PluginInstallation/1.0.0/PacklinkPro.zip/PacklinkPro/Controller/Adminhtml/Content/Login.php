<?php
/**
 * @package    Packlink_PacklinkPro
 * @author     Packlink Shipping S.L.
 * @copyright  2019 Packlink
 */

namespace Packlink\PacklinkPro\Controller\Adminhtml\Content;

/**
 * Class Login
 *
 * @package Packlink\PacklinkPro\Controller\Adminhtml\Content
 */
class Login extends Routing
{
}
