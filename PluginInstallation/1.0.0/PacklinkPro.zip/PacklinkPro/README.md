![Packlink logo](https://pro.packlink.es/public-assets/common/images/icons/packlink.svg)

# Packlink Magento 2 plugin

Please read this document thoroughly in order to prepare for the correct installation.
 
## Installation instructions
Plugin can be installed directly from Magento 2 Marketplace.

There are also options to install the module via composer or to perform manual installation.

### Composer installation
For composer installation you will need your Magento marketplace credentials.
Check [user guide](https://devdocs.magento.com/guides/v2.3/install-gde/prereq/connect-auth.html) 
for information on obtaining them.

Magento 2 module can be installed with Composer. Go to your Magento installation root folder and type this.
```bash
composer require packlink/magento2
```

Composer should automatically find the module in Magento Marketplace and install it. 
Next, module should be enabled with:
```bash
php bin/magento setup:upgrade
```
After installation is over, Packlink configuration can be accessed with _Sales > Packlink PRO_ menu.

### Manual installation
To manually install the extension, follow these steps:

**Step 1:** Extract the content of the `packlink-manual.zip` file and 
upload Packlink folder to your Magento shop `app/code/` directory 
(copy the whole folder) so you have the folders `app/code/Packlink/PacklinkPro`

**Step 2:** Disable the cache in admin panel under _System > Cache Management_

**Step 3:** Now module has to be enabled and Magento recompiled in order to include the module.
```bash
php bin/magento setup:upgrade
php bin/magento setup:di:compile
```

**Step 4:** In case of Magento version less than 2.3, static content needs to be deployed with this command:
```bash
php bin/magento setup:static-content:deploy
```
**Step 5:** Optionally you might need to fix permissions on your Magento files if
the previous steps were ran as a `root` or other non-magento console user

After installation is over, Packlink configuration can be accessed with _Sales > Packlink PRO_ menu.

## Uninstall instructions
### Marketplace installation
If module is installed through the Magento Marketplace, module can be uninstalled
from the _System > Web Setup Wizard > Extension manager_.

### Composer installation
If module is installed via composer, run this command to uninstall it:
```bash
php bin/magento module:uninstall Packlink_PacklinkPro
```

### Manual installation
In a case where module is installed manually, some manual actions are also required to remove the module.
**Step 1:** Disable module by running this command from the Magento root folder and as a magento console user:
```bash
php bin/magento module:disable Packlink_PacklinkPro
```

**Step 2:** Remove module files
```bash
rm -rf app/code/Packlink
```

**Step 3:** Delete module data from database (you will need the access to the database):
```sql
DELETE FROM `setup_module` WHERE `module` = 'Packlink_PacklinkPro';
DROP TABLE `packlink_entity`;
```

**Step 4:** Lastly, rebuild Magento's code:
```bash
php bin/magento setup:upgrade
php bin/magento setup:di:compile
```

## Version
dev

## Compatibility
Magento 2.1.x, 2.2.x and 2.3.x versions

## Prerequisites
- PHP 5.6 or newer
- MySQL 5.6 or newer (integration tests)
