<?php

namespace Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\Exceptions;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions\BaseException;

/**
 * Class EntityClassException.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\Exceptions
 */
class EntityClassException extends BaseException
{
}
