<?php

namespace Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions;

/**
 * Class HttpBaseException. All Http exceptions should inherit from this class.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\Infrastructure\Utility\Exceptions
 */
class HttpBaseException extends \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions\BaseException
{
}
