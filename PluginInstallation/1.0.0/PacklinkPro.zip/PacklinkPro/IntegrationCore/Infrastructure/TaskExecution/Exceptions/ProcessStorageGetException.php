<?php

namespace Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\Exceptions;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions\BaseException;

/**
 * Class ProcessStorageGetException.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\Exceptions
 */
class ProcessStorageGetException extends BaseException
{
}
