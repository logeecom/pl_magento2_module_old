<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ServiceRegister;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Configuration;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Http\DTO\Analytics;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Http\Proxy;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\ShippingMethod\ShippingMethodService;

/**
 * Class AnalyticsController.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers
 */
class AnalyticsController
{
    /**
     * Sends analytics setup event if all conditions are met.
     */
    public static function sendSetupEvent()
    {
        /** @var Configuration $configService */
        $configService = ServiceRegister::getService(Configuration::CLASS_NAME);

        if (!$configService->isSetupFinished()
            && $configService->getDefaultParcel() !== null
            && $configService->getDefaultWarehouse() !== null
        ) {
            /** @var ShippingMethodService $shippingService */
            $shippingService = ServiceRegister::getService(ShippingMethodService::CLASS_NAME);

            if (count($shippingService->getActiveMethods()) === 1) {
                /** @var Proxy $proxy */
                $proxy = ServiceRegister::getService(Proxy::CLASS_NAME);
                $proxy->sendAnalytics(Analytics::EVENT_SETUP);
                $configService->setSetupFinished();
            }
        }
    }

    /**
     * Sends event notifying that other services in the integrated system are disabled.
     */
    public static function sendOtherServicesDisabledEvent()
    {
        /** @var Proxy $proxy */
        $proxy = ServiceRegister::getService(Proxy::CLASS_NAME);
        $proxy->sendAnalytics(Analytics::EVENT_OTHER_SERVICES_DISABLED);
    }
}
