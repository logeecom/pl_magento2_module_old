<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Tasks;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ServiceRegister;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\Task;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Http\Proxy;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Order\Interfaces\OrderRepository;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Order\OrderService;

/**
 * Class UpdateShipmentDataTask
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Tasks
 */
class UpdateShipmentDataTask extends Task
{
    /**
     * Runs task logic.
     *
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions\HttpAuthenticationException
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions\HttpCommunicationException
     * @throws \Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions\HttpRequestException
     * @throws \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Order\Exceptions\OrderNotFound
     */
    public function execute()
    {
        /** @var \Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Order\Interfaces\OrderRepository $orderRepository */
        $orderRepository = ServiceRegister::getService(OrderRepository::CLASS_NAME);
        /** @var Proxy $proxy */
        $proxy = ServiceRegister::getService(Proxy::CLASS_NAME);
        /** @var OrderService $orderService */
        $orderService = ServiceRegister::getService(OrderService::CLASS_NAME);
        $orderReferences = $orderRepository->getIncompleteOrderReferences();

        foreach ($orderReferences as $orderReference) {
            if (!$orderRepository->isShipmentDeleted($orderReference)) {
                $shipment = $proxy->getShipment($orderReference);
                if ($shipment !== null) {
                    $orderService->updateShipmentLabel($orderReference);
                    $orderService->updateTrackingInfo($orderReference, $shipment);
                    $orderService->updateShippingStatus($orderReference, $shipment->status, $shipment);
                    $orderRepository->setShippingPriceByReference($orderReference, (float)$shipment->price);
                } else {
                    $orderRepository->markShipmentDeleted($orderReference);
                }
            }
        }
    }
}
