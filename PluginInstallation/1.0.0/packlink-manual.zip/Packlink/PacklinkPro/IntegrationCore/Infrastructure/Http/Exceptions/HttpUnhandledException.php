<?php

namespace Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions;

/**
 * Class HttpUnhandledException.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\Infrastructure\Utility\Exceptions
 */
class HttpUnhandledException extends HttpBaseException
{

}
