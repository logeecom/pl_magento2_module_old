<?php

namespace Packlink\PacklinkPro\IntegrationCore\Infrastructure\Http\Exceptions;

/**
 * Class HttpAuthenticationException.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\Infrastructure\Utility\Exceptions
 */
class HttpAuthenticationException extends HttpBaseException
{

}
