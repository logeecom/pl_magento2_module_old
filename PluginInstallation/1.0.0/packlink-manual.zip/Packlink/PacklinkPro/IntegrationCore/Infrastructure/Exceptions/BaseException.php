<?php

namespace Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions;

/**
 * Class BaseException. All exceptions defined in this package should inherit from this class.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions
 */
class BaseException extends \Exception
{
}
