<?php

namespace Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\Exceptions;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions\BaseException;

/**
 * Class RepositoryNotRegisteredException.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\Infrastructure\ORM\Exceptions
 */
class RepositoryNotRegisteredException extends BaseException
{
}
