<?php

namespace Packlink\PacklinkPro\IntegrationCore\Infrastructure;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\AsyncProcessStarterService;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\Interfaces\AsyncProcessService;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\Interfaces\TaskRunnerStatusStorage;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\Interfaces\TaskRunnerWakeup;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\QueueService;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\RunnerStatusStorage;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\TaskRunner;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\TaskExecution\TaskRunnerWakeupService;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Utility\Events\EventBus;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Utility\GuidProvider;
use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Utility\TimeProvider;

/**
 * Class BootstrapComponent.
 *
 * @package Packlink\PacklinkPro\IntegrationCore\Infrastructure
 */
class BootstrapComponent
{
    /**
     * Initializes infrastructure components.
     */
    public static function init()
    {
        static::initServices();
        static::initRepositories();
        static::initEvents();
    }

    /**
     * Initializes services and utilities.
     */
    protected static function initServices()
    {
        ServiceRegister::registerService(
            TimeProvider::CLASS_NAME,
            function () {
                return TimeProvider::getInstance();
            }
        );
        ServiceRegister::registerService(
            GuidProvider::CLASS_NAME,
            function () {
                return GuidProvider::getInstance();
            }
        );
        ServiceRegister::registerService(
            EventBus::CLASS_NAME,
            function () {
                return EventBus::getInstance();
            }
        );
        ServiceRegister::registerService(
            AsyncProcessService::CLASS_NAME,
            function () {
                return AsyncProcessStarterService::getInstance();
            }
        );
        ServiceRegister::registerService(
            QueueService::CLASS_NAME,
            function () {
                return new QueueService();
            }
        );
        ServiceRegister::registerService(
            TaskRunnerWakeup::CLASS_NAME,
            function () {
                return new TaskRunnerWakeupService();
            }
        );
        ServiceRegister::registerService(
            TaskRunner::CLASS_NAME,
            function () {
                return new TaskRunner();
            }
        );
        ServiceRegister::registerService(
            TaskRunnerStatusStorage::CLASS_NAME,
            function () {
                return new RunnerStatusStorage();
            }
        );
    }

    /**
     * Initializes repositories.
     */
    protected static function initRepositories()
    {
    }

    /**
     * Initializes events.
     */
    protected static function initEvents()
    {
    }
}
