<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Order\Exceptions;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions\BaseException;

/**
 * Class OrderNotFound
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Order\Exceptions
 */
class OrderNotFound extends BaseException
{
}
