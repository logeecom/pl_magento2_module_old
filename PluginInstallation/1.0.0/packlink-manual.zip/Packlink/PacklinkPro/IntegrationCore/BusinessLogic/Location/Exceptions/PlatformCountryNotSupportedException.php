<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Location\Exceptions;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\Exceptions\BaseException;

class PlatformCountryNotSupportedException extends BaseException
{
}