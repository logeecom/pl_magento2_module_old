<?php

namespace Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers;

use Packlink\PacklinkPro\IntegrationCore\Infrastructure\ServiceRegister;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Configuration;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers\DTO\DashboardStatus;
use Packlink\PacklinkPro\IntegrationCore\BusinessLogic\ShippingMethod\ShippingMethodService;

/**
 * Class DashboardController
 * @package Packlink\PacklinkPro\IntegrationCore\BusinessLogic\Controllers
 */
class DashboardController
{
    /**
     * Fully qualified name of this class.
     */
    const CLASS_NAME = __CLASS__;
    /**
     * Shipping method service.
     *
     * @var ShippingMethodService
     */
    private $shippingMethodService;
    /**
     * Configuration instance.
     *
     * @var Configuration
     */
    private $configuration;

    /**
     * DashboardController constructor.
     */
    public function __construct()
    {
        $this->configuration = ServiceRegister::getService(Configuration::CLASS_NAME);
        $this->shippingMethodService = ServiceRegister::getService(ShippingMethodService::CLASS_NAME);
    }

    /**
     * Returns Dashboard status object with configuration flags.
     *
     * @return DashboardStatus Dashboard status.
     */
    public function getStatus()
    {
        $dashboardDto = new DashboardStatus();
        $dashboardDto->isParcelSet = (bool)$this->configuration->getDefaultParcel();
        $dashboardDto->isWarehouseSet = (bool)$this->configuration->getDefaultWarehouse();
        $dashboardDto->isShippingMethodSet = $this->shippingMethodService->isAnyMethodActive();

        return $dashboardDto;
    }
}
